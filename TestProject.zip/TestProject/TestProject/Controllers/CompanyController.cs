﻿using System.Collections.Generic;
using System.Web.Mvc;
using BusinessLayer;
using TestProject.Models;

namespace TestProject.Controllers {
    public class CompanyController : Controller {
        // GET: Company
        public ActionResult Index() {
            var mgr = AppManager.AppManagerInstance;
            mgr.CompanyName = "Company_X";
            var file = Server.MapPath("~/App_Data/users.json");
            mgr.LoadUsers(file);
            var model = new CompanyModel {
                EmployeeList = new List<EmployeeModel>(),
                Name = mgr.CompanyName
            };
            foreach (var user in mgr.Users) {
                model.EmployeeList.Add(new EmployeeModel {
                    Id = user.Id,
                    Name = user.Name,
                    EmployementType = user.Type,
                    HourlyPayRate = user.Payrate,
                    AccountDetails = user.AccountDetails
                });
            }
            return View(model);
        }
    }
}