﻿using System.Linq;
using System.Web.Mvc;
using BusinessLayer;
using BusinessLayer.BusinessObjects;
using TestProject.Models;

namespace TestProject.Controllers {
    public class EmployeeController : BaseController {
        private readonly IAppManager _mgr = AppManager.AppManagerInstance;

        private void LoadUsers() {
            _mgr.CompanyName = "Company_X";
            var file = Server.MapPath("~/App_Data/users.json");
            _mgr.LoadUsers(file);
        }

        [HttpGet]
        public ActionResult Create() {
            var employee = new EmployeeModel();
            employee.Initilize();
            return View("Create", employee);
        }

        [HttpPost]
        public ActionResult Create(EmployeeModel model) {
            LoadUsers();
            _mgr.Users.Add(new User {
                Id = _mgr.Users.Count + 1,
                Name = model.Name,
                Type = model.EmployementType,
                Payrate = model.HourlyPayRate,
                AccountDetails = new BankAccount {
                    AccountNo = model.AccountDetails!=null?model.AccountDetails.AccountNo:string.Empty,
                    BalanceAmt = 0
                }
            });
            _mgr.UpdateUsers();
            return RedirectToAction("Index", "Company");
        }

        public ActionResult Pay(EmployeeModel model) {
            LoadUsers();
            ViewData["EmployeeList"] = _mgr.Users.Select(x=>new SelectListItem() {
                Text = x.Name,
                Value = x.Id.ToString(),
                Selected = model.Id==x.Id
            });
            if (model.Id>0) {
                var usr = _mgr.Users.FirstOrDefault(x => x.Id == model.Id);
                if (usr!=null) {
                    model.Name = usr.Name;
                    model.EmployementType = usr.Type;
                    model.HourlyPayRate = usr.Payrate;
                    model.AccountDetails = usr.AccountDetails;
                }
            }
            return View(model);
        }

        [HttpPost]
        public ActionResult PayConfirmation(EmployeeModel model) {
            LoadUsers();
            var obj = _mgr.Users.FirstOrDefault(x => x.Id.Equals(model.Id));
            if (obj != null) {
                var payment = obj.Payrate*model.WorkedHours;
                obj.AccountDetails.BalanceAmt = obj.AccountDetails.BalanceAmt + payment;
                ViewData["Name"] = obj.Name;
                ViewData["LastPayment"] = payment;
            }
            _mgr.UpdateUsers();
            return View(model);
        }

    }
}