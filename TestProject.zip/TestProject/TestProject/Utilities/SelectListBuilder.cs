﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestProject.Utilities {
    public static class SelectListBuilder {
        public static SelectList GetEmployementTypeList() {
            return new SelectList(new List<SelectListItem> {
                new SelectListItem {Value = EmployementTypes.Permanent, Text = EmployementTypes.Permanent},
                new SelectListItem {Value = EmployementTypes.Contract, Text = EmployementTypes.Contract}
            }, "Value", "Text", EmployementTypes.Permanent);
        }
    }
}