﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestProject.Utilities;

namespace TestProject.Models {
    public class CompanyModel : BaseModel {
        public string Name { get; set; }
        public List<EmployeeModel> EmployeeList { get; set; }
    }
}