﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestProject.Utilities;
using BusinessLayer;
using BusinessLayer.BusinessObjects;

namespace TestProject.Models {
    public class EmployeeModel:BaseModel {
        public int Id { get; set; }
        public string Name { get; set; }
        public string EmployementType { get; set; }
        public double HourlyPayRate { get; set; }
        public BankAccount AccountDetails { get; set; }
        public SelectList EmployementTypeList { get; set; }
        public int WorkedHours { get; set; }

        public void Initilize() {
            EmployementTypeList = SelectListBuilder.GetEmployementTypeList();
        }
    }
}