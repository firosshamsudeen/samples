﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessLayer.BusinessObjects
{
    public class BankAccount
    {
        public string AccountNo { get; set; }
        public double BalanceAmt { get; set; }
    }
}
