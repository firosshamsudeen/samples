﻿using System.Collections.Generic;
using BusinessLayer.BusinessObjects;

namespace BusinessLayer {
    public interface IAppManager {
        string CompanyName { get; set; }
        List<User> Users { get; set; }

        void UpdateUsers();
        void LoadUsers(string file);
    }
}
