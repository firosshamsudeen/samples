﻿using System.Collections.Generic;
using System.IO;
using BusinessLayer.BusinessObjects;
using System.Web;
using Newtonsoft.Json;

namespace BusinessLayer {
    public class AppManager:IAppManager {
        private static AppManager _appManagerInstance;
        private string _file;

        private AppManager() {

        }

        public static IAppManager AppManagerInstance => _appManagerInstance ?? (_appManagerInstance = new AppManager());

        public string CompanyName { get; set; }
        public List<User> Users { get; set; }

        public void LoadUsers(string file) {
            this._file = file;
            using (var r = new StreamReader(_file)) {
                var json = r.ReadToEnd();
                this.Users = JsonConvert.DeserializeObject<List<User>>(json);
            }
        }

        public void UpdateUsers() {
            var json = JsonConvert.SerializeObject(this.Users.ToArray());
            System.IO.File.WriteAllText(_file, json);
        }
    }
}
